import React, { Component } from "react";

const TravellerDashboard = props => {};

export default TravellerDashboard;
